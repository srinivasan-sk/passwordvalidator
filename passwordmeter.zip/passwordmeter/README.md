# Cool Password Validation – #Angular Reactive Forms

This Angular project is for an accompanying post which can be found [here](http://theinfogrid.com/tech/developers/angular/cool-password-validation-angular/). And the demo for this repo can be found [here](https://mainawycliffe.github.io/ng-bootstrap-password-validation-example/).

To test this repo:

1. First, clone the repo `git clone https://github.com/MainaWycliffe/ng-bootstrap-password-validation-example.git`
2. Then run `yarn install` or `npm install`
3. And finally run `ng s --aot`
